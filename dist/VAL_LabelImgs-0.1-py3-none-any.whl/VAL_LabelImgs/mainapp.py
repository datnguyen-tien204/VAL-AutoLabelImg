from VAL_LabelImgs.main import main
import sys
# mainapp.py
def main_app():
    main()

if __name__ == "__main__":
    sys.exit(main())
